public class App {
    public static void main(String[] args) throws Exception {
    Usuario usuario1= new Usuario("5","learnig.java@gmail.com","ricardo");
    Moderador moderador1= new Moderador("ramon","4","learnig.java@gmail.com",)

    

    }
}
