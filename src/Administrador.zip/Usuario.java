public class Usuario {

    //atributos de la clase usuario.
    private int Mensajes;
    private String Correo;
    private String Nombre;

    //constructor

    public Usuario(String string, String correo, String nombre) {
        this.Mensajes = string;
        this.Correo = correo;
        this.Nombre = nombre;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        this.Nombre = "nick";
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String correo) {
        this.Correo = correo;
    }

    public int getMensajes() {
        return Mensajes++;
    }

    public void setMensajes(int mensajes) {
        this.Mensajes = mensajes--;
    }

    
}
