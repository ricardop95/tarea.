public class Moderador extends Usuario {

    private String Papelera;


    // constructor 
    public Moderador(String nombre,int mensajes,String correo,int papelera);
    
    super(nombre,mensajes,correo);
    this.Papelera=papelera;

    public int getPapelera() {
        return Papelera;
    }


    public void setPapelera(int papelera) {
        this.Papelera = papelera;
    }
// aqui no se que metodo voy a sobre escribir ramon , por que creo que le di valor a olos atributos de
// de la clase usuario de forma incorrecta es lo que creo ..
    @Override

    public void 

    
}
