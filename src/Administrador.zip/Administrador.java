public class Administrador extends Usuario {

    private int Baneo;
    private String papelera;

public Administrador(String nombre,int mensajes,String correo,String papelera,int baneo);

super(nombre,mensajes,correo);
this.baneo=baneo;
this.papelera=papelera;
}

    public int getBaneo() {
        return Baneo;
    }

    public void setBaneo(int baneo) {
        this.Baneo = baneo;
    }

}